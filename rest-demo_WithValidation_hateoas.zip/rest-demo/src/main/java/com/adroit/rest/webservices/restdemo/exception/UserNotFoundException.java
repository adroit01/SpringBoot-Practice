package com.adroit.rest.webservices.restdemo.exception;


public class UserNotFoundException extends Exception{

	public UserNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
