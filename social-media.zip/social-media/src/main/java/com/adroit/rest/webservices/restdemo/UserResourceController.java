package com.adroit.rest.webservices.restdemo;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.adroit.rest.webservices.restdemo.exception.PostAlreadyExistException;
import com.adroit.rest.webservices.restdemo.exception.PostNotFoundExceptions;
import com.adroit.rest.webservices.restdemo.exception.UserAlreadyExistException;
import com.adroit.rest.webservices.restdemo.exception.UserNotFoundException;
import com.adroit.rest.webservices.restdemo.post.Post;
import com.adroit.rest.webservices.restdemo.user.User;
import com.adroit.rest.webservices.restdemo.user.UserDaoService;

@RestController
public class UserResourceController {

	@Autowired
	private UserDaoService userDaoService;
	
	
	//RetrieveAllUsers
	//GET	/users	
	@GetMapping(path = "/users")
	public Set<User> retrieveAllUsers() throws Exception
	{	
		Set<User> users =  userDaoService.getAllUsers();
		if(users == null || users.isEmpty())
		{
			throw new Exception("failed to retrive users");
		}
		return users;
	}
	
	
	
	//RetrieveUser
	//GET /users/{id}
	@GetMapping(path ="/users/{id}")
	public Resource<User> retrieveUser(@PathVariable String id) throws Exception
	{
		User user = userDaoService.getUser(id);
		if(user ==null)
		{
			throw new UserNotFoundException("User with id:" + id + " does not exist");
		}
		
		//HATEOAS- Hypermedia as the engine of application state
		//with detail of user we will also send the link to retrieve all-users
		Resource<User> resource = new Resource<User>(user);
		ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveAllUsers());
		resource.add(link.withRel("All users"));
		
		return resource;
	}
	
	
	//Create a user
	@PostMapping(path="/users")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) throws Exception 
	{
		User createdUser = userDaoService.createUser(user);
		if(createdUser == null)
		{
			throw new UserAlreadyExistException("User with id: " + user.getId() + " Already exsit");
		}
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdUser.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	
	//Number of Users
	@GetMapping(path="/users/userCount")
	public int getUserCount()
	{
		return userDaoService.getUserCount();
	}
	
	//Delete a user
	//DELETE /users/{id}
	@DeleteMapping(path="/users/{id}")
	public void deleteUserById(@PathVariable String id) throws Exception
	{
		boolean isDeleted = userDaoService.deleteUser(id);
		
		if(!isDeleted)
		{
			throw new UserNotFoundException("User with id:" + id + " does not exist");
		}
	}
	
	
	
	@DeleteMapping(path="/users")
	public void deleteAllUser() throws Exception
	{
		userDaoService.deleteAllUsers();
	}
	
	
	
	@GetMapping("/users/{userId}/posts")
	public Set<Resource<Post>> getAllPost(@PathVariable String userId) throws Exception
	{
		User user = userDaoService.getUser(userId);
		if(user ==null)
		{
			throw new UserNotFoundException("User with id:" + userId + " does not exist");
		}
		
		Set<Post> posts = user.getPosts();
		//HATEOAS
		//Get link to corresponding user also
		Set<Resource<Post>> resources = new HashSet<Resource<Post>>();
		for(Post p:posts)
		{
			Resource<Post> r = new Resource<Post>(p);
			ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveUser(user.getId()));
			r.add(link.withRel("User"));
			resources.add(r);
		}
		
		return resources;
	}
	
	@GetMapping(path="/users/{userId}/posts/{postId}")
	public Resource<Post> getAPostForUser(@PathVariable String userId,@PathVariable String postId) throws Exception
	{
		User user = userDaoService.getUser(userId);
		if(user ==null)
		{
			throw new UserNotFoundException("User with id:" + userId + " does not exist");
		}
		Set<Post> posts=  user.getPosts();
		Resource<Post> resource = null;
		for(Post p:posts)
		{
			if(p.getPostId().equals(postId))
			{
				resource= new Resource<Post>(p);
				ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveUser(userId));
				resource.add(link.withRel("User"));
			}
			
		}
		if(resource == null )
		{
			throw new PostNotFoundExceptions("Post with id:"+postId+" does not exist for User with id:"+userId); 
		}
		return resource; 
	}
	
	@PostMapping("/users/{userId}/posts")
	public ResponseEntity<Post> createPost(@PathVariable String userId, @RequestBody Post newPost) throws Exception
	{
		User user = userDaoService.getUser(userId);
		if(user ==null)
		{
			throw new UserNotFoundException("User with id:" + userId + " does not exist");
		}
		Post createdPost = userDaoService.createUserPost(userId, newPost);
		if(createdPost == null)
		{
			throw new PostAlreadyExistException("Post with id: " +newPost.getPostId() + " already exist");
		}
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("postId").buildAndExpand(createdPost.getPostId()).toUri();
		return ResponseEntity.created(location).build();	
	}
	//Delete a single post of a user
	@DeleteMapping("/users/{userId}/posts/{postId}")
	public void deletePost(@PathVariable String userId,@PathVariable String postId) throws Exception
	{
		userDaoService.deleteAPost(userId, postId);
	}
	//Delete all post of a user
	@DeleteMapping("/users/{userId}/posts")
	public void deleteAllPost(@PathVariable String userId) throws Exception
	{
		userDaoService.deleteAllPost(userId);
	}
}
