package com.adroit.rest.webservices.restdemo.user;

import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.springframework.stereotype.Component;

import com.adroit.rest.webservices.restdemo.exception.UserNotFoundException;
import com.adroit.rest.webservices.restdemo.post.Post;

@Component
public class UserDaoService {

	private static Set<User> users = new HashSet<>();
		
	static 
	{
		users.add(new User("1", "Ravi", 38));
		users.add(new User("2", "Sanjay", 25));
		users.add(new User("3", "Rajan", 26));
	}
	private static Integer userCount = users.size(); 
	//createUser
	public User createUser(User user)
	{
		if(user.getId() == null || user.getId().isEmpty())
		{
			userCount++;
			user.setId(userCount.toString());
		}
		boolean isExist = !(users.add(user));
		if(isExist)
		{
			return null;
		}
		return user;
	}
	public User getUser(String id)
	{
		for(User user:users)
		{
			if(user.getId().equals(id))
			{
				return user;
			}
		}
		return null;
	}
	
	public Set<User> getAllUsers()
	{
		return users;
	}
	
	public boolean deleteUser(String id)
	{
		boolean isDeleted = false;
		for(Iterator<User> itr = users.iterator();itr.hasNext();)
		{
			User user= (User)itr.next();
			if(user.getId().equals(id))
			{
				itr.remove();
				isDeleted = true;
			}
		}
		return isDeleted;
	}
	
	public void deleteAllUsers()
	{
		users.clear();
	}
	
	public int getUserCount()
	{
		return userCount;
	}
	
	public Post createUserPost(String userId,Post p) throws Exception
	{
		User user = this.getUser(userId);
		if(user == null)
		{
			throw new UserNotFoundException("User with Id" + userId+ "does not exist");
		}
		if(p.getPostId() == null)
		{
			int presentPostCount = user.getPosts().size();
			String newPostId = "P"+presentPostCount;
			p.setPostId(newPostId);
		}
		boolean isExist = !(user.addPost(p));
		if(isExist)
		{
			return null;
		}
		return p;
	}
	
	public boolean deleteAPost(String userId,String postId) throws Exception
	{
		User user = this.getUser(userId);
		if(user == null)
		{
			throw new UserNotFoundException("User with Id" + userId+ "does not exist");
		}
		for(Iterator<Post> itr = user.getPosts().iterator();itr.hasNext();)
		{
			Post p = (Post)itr;
			if(p.getPostId().equals(postId))
			{
				itr.remove();
				return true;
			}
		}
		return false;
	}
	public void deleteAllPost(String userId) throws Exception
	{
		User user = this.getUser(userId);
		if(user == null)
		{
			throw new UserNotFoundException("User with Id" + userId+ "does not exist");
		}
		user.getPosts().clear();
	}
	
	public Set<Post> getAllPost(String userId)throws Exception
	{
		User user = this.getUser(userId);
		if(user == null)
		{
			throw new UserNotFoundException("User with Id" + userId+ "does not exist");
		}
		return user.getPosts();
	}
}
