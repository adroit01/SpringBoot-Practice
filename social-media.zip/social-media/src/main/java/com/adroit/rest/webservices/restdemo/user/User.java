package com.adroit.rest.webservices.restdemo.user;

import java.util.HashSet;
import java.util.Set;

import javax.validation.constraints.Size;

import com.adroit.rest.webservices.restdemo.post.Post;
public class User {

	private String id;
	@Size(min=2, message="The name should be of min. size 2 character")
	private String name;
	private int age;
	private Set<Post> posts = new HashSet<Post>();
	
	public Set<Post> getPosts() {
		return posts;
	}
	public void setPosts(Set<Post> posts) {
		this.posts = posts;
	}
	
	public boolean addPost(Post post)
	{
		return this.posts.add(post);
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", age=" + age + "]";
	}
	public User()
	{
		
	}
	public User(String id, String name, int age) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
	}
	@Override
	public boolean equals(Object u1)
	{
		if(u1 == this)
		{
			return true;
		}
		if(!(u1 instanceof User))
		{
			return false;
		}
		User u = (User)u1;
		if(this.getId().equals(u.getId()) &&
				this.getName().equals(u.getName())
				&& this.getAge() == u.getAge())
		{
			return true;
		}
		return false;
	}
	@Override 
	public int hashCode()
	{
		int x = 17;
		x = 31*x + this.getId().hashCode();
		x = 31 * x + this.name.hashCode();
		x = 31*x + this.getAge();
		return x;
	}
	 
}
