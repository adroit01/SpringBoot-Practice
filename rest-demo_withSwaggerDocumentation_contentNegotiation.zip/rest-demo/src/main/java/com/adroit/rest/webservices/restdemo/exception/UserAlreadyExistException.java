package com.adroit.rest.webservices.restdemo.exception;

public class UserAlreadyExistException extends Exception {

	public UserAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
