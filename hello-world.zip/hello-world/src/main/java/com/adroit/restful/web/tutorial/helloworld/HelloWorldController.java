package com.adroit.restful.web.tutorial.helloworld;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloWorldController {

	// A Get Request has to be mapped to it
	//user has to be passed in request
	//@RequestMapping(method=RequestMethod.GET,path="/hello-world/{user}")
	@GetMapping("/hello-world/{user}")
	public String getMessage(@PathVariable String user)
	{
		return "Hello" + " "+ user;
	}
}
