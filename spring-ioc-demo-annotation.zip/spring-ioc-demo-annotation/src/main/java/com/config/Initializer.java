package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.domain.Product;

//@ComponentScan(basePackages={"com.config,com.bpp,com.domain"})
@ComponentScan(basePackages={"com.config","com.bpp","com.domain"})
@Configuration
public class Initializer {

	@Bean(name = "product")
	public Product product() {
		
		Product product = new Product();
		product.setId(123);
		product.setName("LG");
		product.setCost(12312d);
		
		return product;
	}
	
	@Bean(name = "product2")
	public Product product2() {
		
		Product product2 = new Product();
		product2.setId(213);
		product2.setName("Sony");
		product2.setCost(22312d);
		
		return product2;
	}
	
	@Bean(name = "product3")
	public Product product3() {
		
		Product product3 = new Product();
		product3.setId(313);
		product3.setName("Oppo");
		product3.setCost(18312d);
		
		return product3;
	}
}
