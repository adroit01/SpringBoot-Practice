package com.test;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.config.Initializer;
import com.domain.Cashier;
import com.domain.Product;
import com.domain.ShoppingCart;

public class Main {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext context = 
				new AnnotationConfigApplicationContext(Initializer.class);
		Product product = context.getBean("product", Product.class);
		Product product2 = context.getBean("product2", Product.class);
		Product product3 = context.getBean("product3", Product.class);
		
		ShoppingCart cart = context.getBean("cart", ShoppingCart.class);
		cart.addProduct(product);
		cart.addProduct(product2);
		cart.addProduct(product3);
		
		Cashier cashier = context.getBean("jerry", Cashier.class);
		cashier.checkout(cart);
		
		context.registerShutdownHook();
		context.close();
	}
}






