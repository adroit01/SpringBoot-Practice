package com.bpp;

import java.io.File;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.stereotype.Component;

import com.domain.Cashier;

@Component
public class PathCheckingBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(
			Object target, String beanName) throws BeansException {
		
		if (target instanceof Cashier) {
			System.out.println("In BeanPostProcessor postProcessBeforeInitialization()");
			File file = new File("c:/abc/");
			if (!file.exists()) {
				
				file.mkdirs();
			}
		}
		
		return target;
	}
	
	@Override
	public Object postProcessAfterInitialization(
			Object target, String beanName) throws BeansException {
		if(target instanceof Cashier)
		{
			System.out.println("In BeanPostProcessor postProcessAfterInitialization()");
		}
		return target;
	}

	

}
