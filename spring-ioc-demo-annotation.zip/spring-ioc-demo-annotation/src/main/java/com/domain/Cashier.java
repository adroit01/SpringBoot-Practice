package com.domain;

import java.io.FileWriter;
import java.io.IOException;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Component;

/**
 * This Bean demonstrate the lifecycle callback methods of a Bean
 * 1. Constructor of Bean is called
 * 2. Properties of Bean is set
 * 3. Aware overridden methods e.g.
 * 		3a. If it is BeanNameAware then setBeanName(String) is called
 * 		3b. If it is BeanFactoryAware then setBeanFactory(BeanFactory) is called
 * 		...
 * 4. BeanPostProcessor's before Initialization callback method(postProcessBeforeInitializationObject target, String beanName) is called
 * 5. Custom init method is called annotated by @PreConstruct
 * 6. If it is InitializingBean then afterPropetiesSet() method is called
 * 7. BeanPostProcessor's after Initialization callback method(postProcessAfterInitialization(Object target, String beanName)) is called
 * 8. Custom destroy method is called annotated by @PostConstruct 
 * 9. If it is DisposableBean then destroy() method is called 
 * @author Amit
 *
 */
@Component(value="jerry")
public class Cashier implements BeanNameAware,InitializingBean,DisposableBean,BeanFactoryAware {

	private String name;
	public String getName() {
		return name;
	}

	public void setName(String name) {
		System.out.println("In Cashier setName()");
		this.name = name;
	}

	private FileWriter fos;
	public Cashier()
	{
		System.out.println("In Cashier Constructor");
	}

	public void checkout(ShoppingCart cart) {

		double totalCost = 0.0;

		for (Product product : cart.getProducts()) {

			totalCost += product.getCost();
		}

		String msg = name + " your total bill is:" + totalCost;
		System.out.println(msg);

		try {
			fos.write(msg);
			fos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	@PostConstruct
	public void init() throws Exception {

		fos = new FileWriter("c:/abc/" + "abc.txt", true);
		System.out.println("in Cashier init()");
	}

	@PreDestroy
	public void customPreDestroy()
	{
		System.out.println("In Cashier customPreDestroy()");
	}

	@Override
	public void setBeanName(String arg0) {

		name = arg0;
		System.out.println("In Cashier setBeanName()");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		// TODO Auto-generated method stub
		System.out.println("In Cashier afterPropertiesSet()");
	}

	@Override
	public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
		// TODO Auto-generated method stub
		System.out.println("In Cashier setBeanFactory()");
	}

	@Override
	public void destroy() throws Exception {
		// TODO Auto-generated method stub
		fos.close();
		System.out.println("in Cashier destroy()");
	}
}
