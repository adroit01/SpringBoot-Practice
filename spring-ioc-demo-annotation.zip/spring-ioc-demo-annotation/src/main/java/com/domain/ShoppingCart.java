package com.domain;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component(value="cart")
@Scope(value = "prototype")
public class ShoppingCart {

	private List<Product> products = new ArrayList<>();

	public void addProduct(Product product) {

		products.add(product);
	}

	public List<Product> getProducts() {
		return products;
	}
}
