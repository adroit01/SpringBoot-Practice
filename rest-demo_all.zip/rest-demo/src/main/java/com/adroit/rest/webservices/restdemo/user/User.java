package com.adroit.rest.webservices.restdemo.user;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.Past;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
@Entity
public class User {

	@Id 
	private String id;
	@Size(min=2, message="The name should be of min. size 2 character")
	private String name;
	private int age;
	@Past(message="The birthdate should not be of future")
	private Date birthDate;
	
	@OneToMany(mappedBy="user")
	@JsonManagedReference
	private List<Post> posts;
	
	public List<Post> getPosts() {
		return posts;
	}
	public void setPosts(List<Post> posts) {
		this.posts = posts;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public Date getBirthDate() {
		return birthDate;
	}
	public void setBirthDate(Date birthDate) {
		this.birthDate = birthDate;
	}
	
	@Override
	public String toString() {
		return "User [id=" + id + ", name=" + name + ", age=" + age + ", birthDate=" + birthDate + "]";
	}
	public User()
	{
		
	}
	public User(String id, String name, int age, Date birthDate) {
		super();
		this.id = id;
		this.name = name;
		this.age = age;
		this.birthDate = birthDate;
	}
	@Override
	public boolean equals(Object u1)
	{
		if(u1 == this)
		{
			return true;
		}
		if(!(u1 instanceof User))
		{
			return false;
		}
		User u = (User)u1;
		if(this.getId().equals(u.getId()) &&
				this.getName().equals(u.getName())
				&& this.getAge() == u.getAge() && this.getBirthDate().compareTo(u.getBirthDate()) == 0)
		{
			return true;
		}
		return false;
	}
	@Override 
	public int hashCode()
	{
		int x = 17;
		x = 31*x + this.getId().hashCode();
		x = 31 * x + this.name.hashCode();
		x = 31*x + this.getAge();
		x= 31*x + this.birthDate.hashCode();
		return x;
	}
	 
}
