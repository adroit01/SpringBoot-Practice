package com.adroit.rest.webservices.restdemo.user;

import static org.springframework.hateoas.mvc.ControllerLinkBuilder.methodOn;

import java.net.URI;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Set;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.Resource;
import org.springframework.hateoas.mvc.ControllerLinkBuilder;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.adroit.rest.webservices.restdemo.exception.PostAlreadyExistException;
import com.adroit.rest.webservices.restdemo.exception.PostNotFoundExceptions;
import com.adroit.rest.webservices.restdemo.exception.UserAlreadyExistException;
import com.adroit.rest.webservices.restdemo.exception.UserNotFoundException;

@RestController
public class UserResourceController {

	@Autowired
	private UserDaoService userDaoService;
	
	@Autowired
	private UserRepository userRepo;
	@Autowired
	private PostRepository postRepo;
	//RetrieveAllUsers
	//GET	/users	
	@GetMapping(path = "/users")
	public Set<User> retrieveAllUsers() throws Exception
	{	
		Set<User> users =  userDaoService.getAllUsers();
		if(users == null || users.isEmpty())
		{
			throw new Exception("failed to retrive users");
		}
		return users;
	}
	
	@GetMapping(path = "/jpa/users")
	public List<User> retrieveAllJpaUsers() throws Exception
	{	
		List<User> users =  userRepo.findAll();
		if(users == null || users.isEmpty())
		{
			throw new Exception("failed to retrive users");
		}
		return users;
	}
	
	//RetrieveUser
	//GET /users/{id}
	@GetMapping(path ="/users/{id}")
	public Resource<User> retrieveUser(@PathVariable String id) throws Exception
	{
		User user = userDaoService.getUser(id);
		if(user ==null)
		{
			throw new UserNotFoundException("User with id:" + id + " does not exist");
		}
		
		//HATEOAS- Hypermedia as the engine of application state
		//with detail of user we will also send the link to retrieve all-users
		Resource<User> resource = new Resource<User>(user);
		ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveAllUsers());
		resource.add(link.withRel("All users"));
		
		return resource;
	}
	
	@GetMapping(path ="/jpa/users/{id}")
	public Resource<Optional<User>> retrieveJpaUser(@PathVariable String id) throws Exception
	{
		Optional<User> user = userRepo.findById(id);
		if(user == null)
		{
			throw new UserNotFoundException("User with id:" + id + " does not exist");
		}
		
		//HATEOAS- Hypermedia as the engine of application state
		//with detail of user we will also send the link to retrieve all-users
		Resource<Optional<User>> resource = new Resource<Optional<User>>(user);
		ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveAllJpaUsers());
		resource.add(link.withRel("All users"));
		return resource;
	}
	//Create a user
	@PostMapping(path="/users")
	public ResponseEntity<User> createUser(@Valid @RequestBody User user) throws Exception 
	{
		User createdUser = userDaoService.createUser(user);
		if(createdUser == null)
		{
			throw new UserAlreadyExistException("User with id: " + user.getId() + " Already exsit");
		}
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdUser.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	@PostMapping(path="/jpa/users")
	public ResponseEntity<User> createJpaUser(@Valid @RequestBody User user) throws Exception 
	{
		User createdUser = userRepo.save(user);
		if(createdUser == null)
		{
			throw new UserAlreadyExistException("User with id: " + user.getId() + " Already exsit");
		}
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(createdUser.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	
	//Number of Users
	@GetMapping(path="/users/userCount")
	public int getUserCount()
	{
		return userDaoService.getUserCount();
	}
	
	@GetMapping(path="/jpa/users/userCount")
	public long getJpaUserCount()
	{
		return userRepo.count();
	}
	
	//Delete a user
	//DELETE /users/{id}
	@DeleteMapping(path="/users/{id}")
	public void deleteUserById(@PathVariable String id) throws Exception
	{
		boolean isDeleted = userDaoService.deleteUser(id);
		
		if(!isDeleted)
		{
			throw new UserNotFoundException("User with id:" + id + " does not exist");
		}
	}
	
	//Delete a user
		//DELETE /jpa/users/{id}
		@DeleteMapping(path="/jpa/users/{id}")
		public void deleteJpaUserById(@PathVariable String id) throws Exception
		{
			userRepo.deleteById(id);
		}
	
	@DeleteMapping(path="/users")
	public void deleteAllUser() throws Exception
	{
		userDaoService.deleteAllUsers();
	}
	
	@DeleteMapping(path="/jpa/users")
	public void deleteAllJpaUser() throws Exception
	{
		userRepo.deleteAll();
	}
	
	@GetMapping("/jpa/users/{userId}/posts")
	public List<Resource<Post>> getAllPost(@PathVariable String userId) throws Exception
	{
		User user = userRepo.getOne(userId);
		if(user == null)
		{
			throw new UserNotFoundException("user with id:"+ userId+ "does not exist");
		}
		
		List<Post> posts = user.getPosts();
		//HATEOAS
		//Get link to corresponding user also
		List<Resource<Post>> resources = new ArrayList<Resource<Post>>();
		for(Post p:posts)
		{
			Resource<Post> r = new Resource<Post>(p);
			ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveJpaUser(user.getId()));
			r.add(link.withRel("User"));
			resources.add(r);
		}
		
		return resources;
	}
	
	@GetMapping(path="/jpa/users/{userId}/posts/{postId}")
	public Resource<Post> getAPostForUser(@PathVariable String userId,@PathVariable String postId) throws Exception
	{
		Optional<User> user = userRepo.findById(userId);
		if(!user.isPresent())
		{
			throw new UserNotFoundException("user with id:"+userId+" does not exist");
		}
		List<Post> posts=  user.get().getPosts();
		Resource<Post> resource = null;
		for(Post p:posts)
		{
			if(p.getPostId().equals(postId))
			{
				resource= new Resource<Post>(p);
				ControllerLinkBuilder link = ControllerLinkBuilder.linkTo(methodOn(this.getClass()).retrieveJpaUser(userId));
				resource.add(link.withRel("User"));
			}
			
		}
		if(resource == null )
		{
			throw new PostNotFoundExceptions("Post with id:"+postId+" does not exist for User with id:"+userId); 
		}
		return resource; 
	}
	
	@PostMapping("/jpa/users/{userid}/posts")
	public ResponseEntity<Post> createPost(@Valid @RequestBody Post post) throws Exception
	{
		Post createdPost = postRepo.save(post);
		if(createdPost == null)
		{
			throw new PostAlreadyExistException("Post with id: " +post.getPostId() + " already exist");
		}
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("postId").buildAndExpand(createdPost.getPostId()).toUri();
		return ResponseEntity.created(location).build();	
	}
	//Delete a single post of a user
	@DeleteMapping("/jpa/users/{userid}/posts/{postId}")
	public void deletePost(@PathVariable String postId)
	{
		postRepo.deleteById(postId);
	}
	//Delete all post of a user
	@DeleteMapping("/jpa/users/{userId}/posts")
	public void deleteAllPost(@PathVariable String userId) throws Exception
	{
		User user = userRepo.getOne(userId);
		if(user == null)
		{
			throw new UserNotFoundException("user with id:"+userId+" does not exist");
		}
		for(Post p:user.getPosts())
		{
			postRepo.delete(p);
		}
	}
}
