package com.adroit.rest.webservices.restdemo.exception;

public class PostAlreadyExistException extends Exception {

	public PostAlreadyExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
