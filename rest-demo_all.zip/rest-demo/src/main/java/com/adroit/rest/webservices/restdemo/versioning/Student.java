package com.adroit.rest.webservices.restdemo.versioning;

public class Student {

	private String name;
	private String rollno;
	public Student()
	{
		
	}
	public Student(String name, String rollno, String id) {
		super();
		this.name = name;
		this.rollno = rollno;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getRollno() {
		return rollno;
	}
	public void setRollno(String rollno) {
		this.rollno = rollno;
	}
	
}
