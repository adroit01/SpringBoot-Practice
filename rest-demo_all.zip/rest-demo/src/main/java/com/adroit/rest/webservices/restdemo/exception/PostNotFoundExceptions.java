package com.adroit.rest.webservices.restdemo.exception;

public class PostNotFoundExceptions extends Exception {

	public PostNotFoundExceptions(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
