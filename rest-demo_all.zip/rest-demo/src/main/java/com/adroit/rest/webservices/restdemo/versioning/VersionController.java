package com.adroit.rest.webservices.restdemo.versioning;

public class VersionController {

}
