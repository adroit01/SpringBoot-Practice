--User
insert into user values('1000',25,sysdate(),'Anil')
insert into user values('1001',25,sysdate(),'Sunil')
insert into user values('1002',25,sysdate(),'Bipin')

--UserPosts
insert into post values('P1','Welcome to spring world','1000')
insert into post values('P2','spring,spring','1000')
insert into post values('P3','Microservices world','1001')
