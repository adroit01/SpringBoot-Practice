package com.bpp;

import java.io.File;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

import com.domain.Cashier;

public class PathCheckingBeanPostProcessor implements BeanPostProcessor {

	@Override
	public Object postProcessBeforeInitialization(
			Object target, String beanName) throws BeansException {
		
		if (target instanceof Cashier) {
			
			File file = new File("c:/abc/");
			if (!file.exists()) {
				
				file.mkdirs();
			}
		}
		
		return target;
	}
	
	@Override
	public Object postProcessAfterInitialization(
			Object target, String beanName) throws BeansException {

		return target;
	}

	

}
