package com.test;

import java.util.Arrays;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.domain.Cashier;
import com.domain.Product;
import com.domain.ShoppingCart;

public class Main {

	public static void main(String[] args) {
		
		ConfigurableApplicationContext context = 
				new ClassPathXmlApplicationContext("mybean.xml");
		context.setId("ABC");
		displayContextDetails(context);
		
		Product product = context.getBean("product", Product.class);
		Product product2 = context.getBean("product2", Product.class);
		Product product3 = context.getBean("product3", Product.class);
		
		ShoppingCart cart = context.getBean("cart", ShoppingCart.class);
		cart.addProduct(product);
		cart.addProduct(product2);
		cart.addProduct(product3);
		
		Cashier cashier = context.getBean("jerry", Cashier.class);
		cashier.checkout(cart);
		
		context.registerShutdownHook();
		context.close();
	}
	
	static void displayContextDetails(ApplicationContext context)
	{
		System.out.println("ApplicationContext Id:" +context.getId());
		System.out.println("ApplicationContext Application Name:" + context.getApplicationName());
		System.out.println("ApplicationContext Application Name:" +context.getDisplayName());
		System.out.println("BeanCount:"+context.getBeanDefinitionCount());
		System.out.println("BeanNames:"+Arrays.asList(context.getBeanDefinitionNames()).toString());
		
	}
}






