package com.domain;

import java.io.FileWriter;
import java.io.IOException;

import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Cashier implements BeanNameAware, InitializingBean, DisposableBean {

	private String name;
	private FileWriter fos;
	
	public void checkout(ShoppingCart cart) {

		double totalCost = 0.0;

		for (Product product : cart.getProducts()) {

			totalCost += product.getCost();
		}

		String msg = name + " your total bill is:" + totalCost;
		System.out.println(msg);
		
		try {
			fos.write(msg);
			fos.flush();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		
		fos = new FileWriter("c:/abc/" + "abc.txt", true);
	}
	
	@Override
	public void destroy() throws Exception {
	
		fos.close();
	}

	@Override
	public void setBeanName(String arg0) {

		name = arg0;
	}
}
